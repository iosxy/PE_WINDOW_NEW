//
//  ArticleItemVideoView.swift
//  Yuwan
//
//  Created by 亚鑫柳 on 2017/11/7.
//  Copyright © 2017年 lqs. All rights reserved.
//

import UIKit

class ArticleItemVideoView: UIView {
    @IBOutlet weak var coverView: UIImageView!
}
