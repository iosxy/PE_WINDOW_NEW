//
//  GuestView.swift
//  Yuwan
//
//  Created by lqs on 2017/7/23.
//  Copyright © 2017年 lqs. All rights reserved.
//

import UIKit

class GuestView: UIView {

    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
