
#ifndef StarNews_Bridging_Header_h
#define StarNews_Bridging_Header_h

@import UIKit;
#import <SDWebImage/SDImageCache.h>
#import "JPUSHService.h"
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif

#import "GTMBase64.h"

#endif
