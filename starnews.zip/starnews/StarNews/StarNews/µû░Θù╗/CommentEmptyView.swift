//
//  CommentEmptyView.swift
//  Yuwan
//
//  Created by 亚鑫柳 on 2017/10/21.
//  Copyright © 2017年 lqs. All rights reserved.
//

import UIKit

class CommentEmptyView: UIView {
    
}
